const cloudinary= require('cloudinary')
    cloudinary.config({
    cloud_name: 'dcbceilte',
    api_key:'492949868439187',
    api_secret: 'zEB1Fc05GDScHTwOj6SIGLzjaxI',
  });


module.exports=cloudinary
// cloudinary file is updated
