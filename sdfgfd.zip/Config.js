/*    it was created------
const url=process.env.URL
const jwts=process.env.JWT
module.exports={
    url,jwts
}

*/